# Colección Visera-HX-8K-Visor Hat Collection

Bloques creados por Miguel Grassi.

![](https://raw.githubusercontent.com/Obijuan/digital-electronics-with-open-FPGAs-tutorial/master/wiki/Tutorial-31/jedi-collection-01.png)


## Install

* Download the collection: [stable](https://github.com/FPGAwars/Collection-Jedi/archive/v1.10.0.zip) or [development](https://github.com/FPGAwars/Collection-Jedi/archive/master.zip)
* Install the collection: *Tools > Collections > Add*
* Load the collection: *Select > Collection*

## Blocks
* *Display_2dig_Dec_Hex*
* *EncoderContadorFF*
* *Switch_PullUp*

## Examples
* *Displays*
  * Ejemplo_BlockDisplay_2dig
  
## Authors
* [Miguel Oscar Grassi (migrassi)](https://miguelgrassi.com.ar)


## License

Licensed under [GPL-2.0](https://opensource.org/licenses/GPL-2.0).
